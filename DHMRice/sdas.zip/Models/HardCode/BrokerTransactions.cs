﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DHMRice.Models.HardCode
{
    public static class BrokerTransactions
    {
        public const string PaycommissionToBroker = "PaycommissionToBroker";
    }
}