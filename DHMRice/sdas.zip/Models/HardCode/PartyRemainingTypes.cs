﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DHMRice.Models.HardCode
{
    public static class PartyRemainingTypes
    {
        public const string Payed = "PartyRemaining Payed";
        public const string Received = "PartyRemaining Received";
    }
}